"""The Bowling Game Scorer."""

# Standard Library

# 3rd Party Library

# Project Library


# -----------------------------------------------------------------------------
class BowlingFrame:
    """Keeping the record of each bowling frame."""

    def __init__(self, max_roll = 2):
        """Construct a frame."""
        self.pins = [0]*max_roll
        self.max_roll = max_roll
        self.next_roll = 0

    def roll(self, pins: int):
        """Roll the ball swipe pins"""
        if self.next_roll < self.max_roll:
            self.pins[self.next_roll] = pins
            self.next_roll = self.next_roll + 1

    def score(self):
        """Score of each frame."""
        total = 0
        for index in range(self.max_roll):
            total = total + self.pins[index]
        return total

    def is_spare(self):
        """Check if the current frame is a spare."""

    def is_strike(self):
        """Check if the current frame is a strike."""



# -----------------------------------------------------------------------------
class BowlingFrame10(BowlingFrame):
    """Keeping the record of the 10th bowling frame."""

    def __init__(self):
        """Construct a frame."""
        super().__init__(3)


# -----------------------------------------------------------------------------
class BowlingGame:
    """The Bowling Game."""

    GAME_COMPLETE = -1

    def __init__(self):
        """Construct a BowlingGame object."""
        self.frames = []
        for _ in range(9):
            self.frames.append(BowlingFrame())

        self.frames.append(BowlingFrame10())
        self.cur_frame = 0      # current frame index
        self.cur_roll = 1       # current roll in frame

    def roll(self, num_of_pins: int):
        """Roll a bowling ball.

        Args:
            num_of_pins: The number of knocked-down pins

        Returns:
            None

        """
        index = self.cur_frame
        self.frames[index].roll(num_of_pins)
        if self.cur_roll == 1:
            if num_of_pins == 10:  # Strike
                if index < 9:  # Not in Frame 10
                    self.cur_frame += 1
                self.cur_roll = 1
            else:
                self.cur_roll += 1
        elif self.cur_roll == 2:
            if self.frames[index].is_spare():
                if index < 9:  # Not in Frame 10
                    self.cur_frame += 1
                self.cur_roll = 1
            else:
                if index < 9:  # Not in Frame 10
                    self.cur_frame += 1
                self.cur_roll = 1
        elif self.cur_roll == 3 and index == 9:
            self.cur_roll += 1
        else:
            print("Error: Too many rolls")

    def score(self):
        """Get the current score.

        Returns:
            The current score.

        """
        total_score = 0

        for index, frame in enumerate(self.frames):
            total_score += frame.score()
            if index < 9:  # Not in Frame 10
                if frame.is_strike():
                    total_score += self.strike_bonus(index)
                elif frame.is_spare():
                    total_score += self.spare_bonus(index)

        return total_score

    def strike_bonus(self, index):
        """Calculate bonus points for a strike."""
        next_frame = self.frames[index + 1]
        if next_frame.is_strike() and index < 8:  # Not in the 9th frame
            return next_frame.get_first_roll() + self.frames[index + 2].get_first_roll()
        else:
            return next_frame.get_first_roll() + next_frame.get_second_roll()

    def spare_bonus(self, index):
        """Calculate bonus points for a spare."""
        return self.frames[index + 1].get_first_roll()


class BowlingFrame:
    """A single frame in a game of bowling."""

    MAX_PINS = 10

    def __init__(self):
        """Construct a BowlingFrame object."""
        self.rolls = []

    def roll(self, num_of_pins: int):
        """Roll a bowling ball.

        Args:
            num_of_pins: The number of knocked-down pins

        Returns:
            None

        """
        if self.get_remaining_pins() >= num_of_pins:
            self.rolls.append(num_of_pins)
        else:
            print("Error: Invalid number of pins")

    def is_strike(self):
        """Check if the frame is a strike."""
        return len(self.rolls) == 1 and self.rolls[0] == self.MAX_PINS

    def is_spare(self):
        """Check if the frame is a spare."""
        return len(self.rolls) == 2 and sum(self.rolls) == self.MAX_PINS

    def get_first_roll(self):
        """Get the number of knocked-down pins in the first roll."""
        return self.rolls[0] if self.rolls else 0

    def get_second_roll(self):
        """Get the number of knocked-down pins in the second roll."""
        return self.rolls[1] if len(self.rolls) > 1 else 0

    def get_remaining_pins(self):
        """Get the number of remaining pins."""
        return self.MAX_PINS - sum(self.rolls)

    def score(self):
        """Calculate the score for the frame."""
        return sum(self.rolls)


class BowlingFrame10(BowlingFrame):
    """Special frame for the 10th frame in a game of bowling."""

    def __init__(self):
        """Construct a BowlingFrame10 object."""
        super().__init__()
        self.max_rolls = 3

    def roll(self, num_of_pins: int):
        """Roll a bowling ball in the 10th frame.

        Args:
            num_of_pins: The number of knocked-down pins

        Returns:
            None

        """
        if len(self.rolls) < self.max_rolls:
            self.rolls.append(num_of_pins)
        else:
            print("Error: Too many rolls in the 10th frame")

    def score(self):
        """Calculate the score for the 10th frame."""
        return sum(self.rolls)

# The Bowling Game Kata

An implementation of the Bowling Game Kata (described by Robert J. Martin).  In this version, we use Python and pytest.


## Reference
1. http://butunclebob.com/ArticleS.UncleBob.TheBowlingGameKata
